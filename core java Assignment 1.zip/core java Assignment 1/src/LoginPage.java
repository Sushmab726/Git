import java.util.Scanner;

public class LoginPage {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s=" ";
        System.out.println("Enter the Username");
        String username = sc.nextLine();
        if((username.contains(s)) || username.length()<4){
            System.out.println("Invalid Username");
            return;
        }

        System.out.println("Enter the Password");
        String upass = sc.nextLine();
        if((upass.contains(s)) || upass.length()<8){
            System.out.println("Invalid Password");
            return;
        }

        System.out.println(username+" you are Registered Successfully");
        System.out.println("Enter the Username");
        String lname = sc.nextLine();
        System.out.println("Enter the Password");
        String lpass = sc.nextLine();

        if(username.equals(lname) && upass.equals(lpass)){
            System.out.println("Welcome "+lname+" you have Logged-in Successfully");
        }
        else{
            System.out.println("Username or password Mismatch");
        }
    }
}
