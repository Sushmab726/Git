import java.util.Scanner;

public class ArmstrongNum {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number : ");
		int num = sc.nextInt(); //153
		int temp = num; //153
		int rem = 0 ; 
		int rev = 0 ;
		while(temp != 0) { 
		rem = temp % 10 ; //3 5 1
		temp = temp / 10 ; //15 1 0
		rev = rev +(rem*rem*rem); //0+27 , 27+125, 152+1
		}//terminate
		System.out.println(rev);
		if(rev == num) {
		System.out.println("Number is Armstrong Number..");
		}
		else {
		System.out.println("Number is Not Armstrong..");
		}
		}
}
